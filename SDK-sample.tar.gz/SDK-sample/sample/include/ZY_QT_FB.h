#ifndef __ZY_QT_FB__
#define __ZY_QT_FB__


int ZY_MPI_FB_Open(int fb,int width,int height);



#endif
