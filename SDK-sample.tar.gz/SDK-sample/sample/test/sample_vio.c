/******************************************************************************
  A simple program of Hisilicon Hi35xx video input and output implementation.
  Copyright (C), 2014-2015, Hisilicon Tech. Co., Ltd.
 ******************************************************************************
    Modification:  2015-1 Created
******************************************************************************/

#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* End of #ifdef __cplusplus */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>

#include "sample_comm.h"
#include "sample_comm_ivs.h"



#include "hi_tde_api.h"
#include "hi_tde_type.h"
#include "hifb.h"
#include <linux/fb.h>
#include <sys/mman.h>

#include <linux/fb.h>
#include "hifb.h"
#include "hi_tde_errcode.h"

#include "tlv320aic31.h"
#include "audio_aac_adp.h"



#include "hi_tde_api.h"
#include "hi_tde_type.h"
#include "hifb.h"
#include <linux/fb.h>
#include <sys/mman.h>

#include <linux/fb.h>
#include "hifb.h"
#include "hi_tde_errcode.h"


#include "ZY_RtmpPush.h"
#include "ZY_Demux.h"
#include "ZY_Muxer.h"
#include "ZY_RtspServer.h"

#include "ZY_Sec.h"
#include "ZY_OSD.h"


#define FFMPEG_V2 2
#define FFMPEG_V3 3

#define FFMPGE_VERTION FFMPEG_V2

#define SEND 0
#define READ 1

//#define BOARD READ  
#define BOARD SEND


#define __DEBUG__
#ifdef __DEBUG__
#define DBG(fmt, args...) printf("[%s()-%d] "fmt"\n", __FUNCTION__, __LINE__, ##args)
#else
#define DBG(fmt, args...)
#endif


#if 1

#define DEBUG(fmt, args...) printf("[%s()-%d] "fmt"\n", __FUNCTION__, __LINE__, ##args)


#else

#define DEBUG(fmt, args...)  



#endif 


#define SAMPLE_DBG(s32Ret)\
do{\
    printf("s32Ret=%#x,fuc:%s,line:%d\n", s32Ret, __FUNCTION__, __LINE__);\
}while(0)


#define STREAM_PIX_FMT    AV_PIX_FMT_YUV420P /* default pix_fmt */



typedef struct _vdecInfo{
    int chn;
	char url[1024];
} vdecInfo;








#define HDMI_SUPPORT

VIDEO_NORM_E gs_enNorm = VIDEO_ENCODING_MODE_NTSC;






/******************************************************************************
* function : show usage
******************************************************************************/
void SAMPLE_VIO_Usage(char *sPrgNm)
{
    printf("Usage : %s + <index> (eg: %s 0)\n", sPrgNm,sPrgNm);
    printf("index:\n");
	printf("\t0:  VI 1080P input, HD0(VGA+BT1120),HD1(HDMI)/SD VO \n");
	printf("\t1:  VI 1080p input, HD ZoomIn\n");
	printf("\tq:  quit\n");

    return;
}

/******************************************************************************
* function : to process abnormal case
******************************************************************************/
void SAMPLE_VIO_HandleSig(HI_S32 signo)
{
    if (SIGINT == signo || SIGTERM == signo)
    {   SAMPLE_COMM_VO_HdmiStop();
        SAMPLE_COMM_SYS_Exit();
        printf("\033[0;31mprogram termination abnormally!\033[0;39m\n");
    }
    exit(-1);
}

#if 1
HI_S32 ZY_AUDIO_TLV320AIC31AiAo(HI_VOID)
{
	HI_S32 s32Ret, s32AiChnCnt, s32AoChnCnt;
	AUDIO_DEV	AiDev = SAMPLE_AUDIO_AI_DEV;
	AI_CHN		AiChn = 0;
	AUDIO_DEV	AoDev = SAMPLE_AUDIO_AO_DEV;
	AO_CHN		AoChn = 0;
	AENC_CHN    AeChn = 0;
	ADEC_CHN 	AdChn = 0;
	AIO_ATTR_S stAioAttr;


	stAioAttr.enSamplerate	 = AUDIO_SAMPLE_RATE_48000;
	stAioAttr.enBitwidth	 = AUDIO_BIT_WIDTH_16;
	stAioAttr.enWorkmode	 = AIO_MODE_I2S_SLAVE;
	stAioAttr.enSoundmode	 = AUDIO_SOUND_MODE_STEREO;
	stAioAttr.u32EXFlag 	 = 1;
	stAioAttr.u32FrmNum 	 = 30;
	stAioAttr.u32PtNumPerFrm = SAMPLE_AUDIO_PTNUMPERFRM;
	stAioAttr.u32ChnCnt 	 = 2;
	stAioAttr.u32ClkChnCnt	 = 2;
	stAioAttr.u32ClkSel 	 = 1;


    s32Ret = HI_MPI_AENC_AacInit();
    if(HI_SUCCESS != s32Ret)
    {
        printf("%s: aac aenc init failed with %d!\n", __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }
    s32Ret = HI_MPI_ADEC_AacInit();
    if(HI_SUCCESS != s32Ret)
    {
        printf("%s: aac adec init failed with %d!\n", __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }


	/* config audio codec */
	s32Ret = SAMPLE_COMM_AUDIO_CfgAcodec(&stAioAttr);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_DBG(s32Ret);
		return HI_FAILURE;
	}

	/* enable AI channle */
	s32AiChnCnt = stAioAttr.u32ChnCnt >> stAioAttr.enSoundmode;

	s32Ret = SAMPLE_COMM_AUDIO_StartAi(AiDev, 1, &stAioAttr, AUDIO_SAMPLE_RATE_BUTT,
		HI_FALSE, NULL, 0);
	if (s32Ret != HI_SUCCESS)
	{
		SAMPLE_DBG(s32Ret);
		return HI_FAILURE;
	}

	#if 1
	/* enable AO channle */
	stAioAttr.u32ChnCnt = 2;
	s32AoChnCnt = stAioAttr.u32ChnCnt >> stAioAttr.enSoundmode;

	s32Ret = SAMPLE_COMM_AUDIO_StartAo(AoDev, 1, &stAioAttr, AUDIO_SAMPLE_RATE_BUTT,
	HI_FALSE, NULL, 0);
	if (s32Ret != HI_SUCCESS)
	{
		SAMPLE_DBG(s32Ret);
		return HI_FAILURE;
	}
	#endif 

	/* bind AI to AO channle */

    s32Ret = SAMPLE_COMM_AUDIO_StartAenc(1, &stAioAttr, PT_AAC);
    if (s32Ret != HI_SUCCESS)
    {
        SAMPLE_DBG(s32Ret);
        return HI_FAILURE;
    }

	AeChn = 0;
	AiChn = 0;
	s32Ret = SAMPLE_COMM_AUDIO_AencBindAi(AiDev, AiChn, AeChn);
	if (s32Ret != HI_SUCCESS)
	{
		SAMPLE_DBG(s32Ret);
		return s32Ret;
	}

	#if 1
	s32Ret = SAMPLE_COMM_AUDIO_CreatTrdAenc(AeChn);
	if (s32Ret != HI_SUCCESS)
	{
		SAMPLE_DBG(s32Ret);
		return s32Ret;
	}
	#endif 

	#if 0
	s32Ret = SAMPLE_COMM_AUDIO_AoBindAi(AiDev, AiChn, AoDev, AoChn);
	if (s32Ret != HI_SUCCESS)
	{
		SAMPLE_DBG(s32Ret);
		return HI_FAILURE;
	}
	#endif 


	s32Ret = SAMPLE_COMM_AUDIO_StartAdec(AdChn, PT_AAC);
	if (s32Ret != HI_SUCCESS)
	{
		SAMPLE_DBG(s32Ret);
		return HI_FAILURE;
	}

	s32Ret = SAMPLE_COMM_AUDIO_AoBindAdec(AoDev, AoChn, AdChn);
	if (s32Ret != HI_SUCCESS)
	{
		SAMPLE_DBG(s32Ret);
		return HI_FAILURE;
	}


	return HI_SUCCESS;
	if (1)
	{
		s32Ret = SAMPLE_COMM_AUDIO_CreatTrdAiAo(AiDev, AiChn, AoDev, AoChn);
		if (s32Ret != HI_SUCCESS)
		{
			SAMPLE_DBG(s32Ret);
			return HI_FAILURE;
		}
	}
	else
	{
		s32Ret = SAMPLE_COMM_AUDIO_AoBindAi(AiDev, AiChn, AoDev, AoChn);
		if (s32Ret != HI_SUCCESS)
		{
			SAMPLE_DBG(s32Ret);
			return HI_FAILURE;
		}
	}
	printf("ai(%d,%d) bind to ao(%d,%d) ok\n", AiDev, AiChn, AoDev, AoChn);

	if(0)
	{
		s32Ret = SAMPLE_COMM_AUDIO_CreatTrdAoVolCtrl(AoDev);
		if(s32Ret != HI_SUCCESS)
		{
			SAMPLE_DBG(s32Ret);
			return HI_FAILURE;
		}
	}



	return HI_SUCCESS;
}

#endif 




/******************************************************************************
* function : VI(1080P: 8 windows) -> VPSS -> HD0(1080P,VGA,BT1120)
                                         -> HD1(1080P,HDMI)
                                         -> SD0(D1)
******************************************************************************/
HI_S32 ZY_Video_Sample(HI_VOID)
{
	SAMPLE_VI_MODE_E enViMode = SAMPLE_VI_MODE_4_4Kx2K;
	VIDEO_NORM_E enNorm = VIDEO_ENCODING_MODE_NTSC;

	HI_U32 u32ViChnCnt = 6;
	HI_S32 s32VpssGrpCnt = 16;

	VB_CONF_S stVbConf,stModVbConf;
	VPSS_GRP VpssGrp;
	VPSS_GRP_ATTR_S stGrpAttr;
    VPSS_CHN VpssChn_VoHD0 = VPSS_CHN1;
	VPSS_CHN VpssChn_VoHD1 = VPSS_CHN2;
	VPSS_CHN VpssChn_VoSD0 = VPSS_CHN3;

	VO_DEV VoDev;
	VO_LAYER VoLayer;
	VO_CHN VoChn;
	VO_PUB_ATTR_S stVoPubAttr_hd0, stVoPubAttr_hd1, stVoPubAttr_sd;
	VO_VIDEO_LAYER_ATTR_S stLayerAttr;
	SAMPLE_VO_MODE_E enVoMode, enPreVoMode;

	HI_S32 i;
	HI_S32 s32Ret = HI_SUCCESS;
	HI_U32 u32BlkSize;
	HI_S32 ch;
	SIZE_S stSize;
	HI_U32 u32WndNum;
	HI_U32 vichn;


    PAYLOAD_TYPE_E enPayLoad[2]= {PT_H264, PT_H264};
    PIC_SIZE_E enSize[2] = {PIC_HD1080, PIC_HD1080};
	HI_U32 u32Profile = 0;
    
    VENC_CHN VencChn;
    SAMPLE_RC_E enRcMode= SAMPLE_RC_CBR;
	VENC_PARAM_INTRA_REFRESH_S stIntraRefresh;
	VENC_SUPERFRAME_CFG_S stSuperFrmParam;
	
	HI_U32 u32VdCnt = 4;
	VDEC_CHN_ATTR_S stVdecChnAttr[VDEC_MAX_CHN_NUM];
	

	/******************************************
	 step  1: init variable
	******************************************/
	memset(&stVbConf,0,sizeof(VB_CONF_S));
	u32BlkSize = SAMPLE_COMM_SYS_CalcPicVbBlkSize(enNorm,\
				PIC_UHD4K, SAMPLE_PIXEL_FORMAT, SAMPLE_SYS_ALIGN_WIDTH,COMPRESS_MODE_SEG);
	stVbConf.u32MaxPoolCnt = 128;

	/* video buffer*/
	//todo: vb=15
	stVbConf.astCommPool[0].u32BlkSize = u32BlkSize;
	stVbConf.astCommPool[0].u32BlkCnt = 4 * 12;


	u32BlkSize = SAMPLE_COMM_SYS_CalcPicVbBlkSize(enNorm,\
				PIC_HD1080, SAMPLE_PIXEL_FORMAT, SAMPLE_SYS_ALIGN_WIDTH,COMPRESS_MODE_SEG);

	/* video buffer*/
	//todo: vb=15
	stVbConf.astCommPool[1].u32BlkSize = u32BlkSize;
	stVbConf.astCommPool[1].u32BlkCnt = 4 * 16;	

	/******************************************
	 step 2: mpp system init.
	******************************************/
	s32Ret = SAMPLE_COMM_SYS_Init(&stVbConf);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("system init failed with %d!\n", s32Ret);
		goto END_8_1080P_0;
	}

	s32Ret = SAMPLE_COMM_SYS_GetPicSize(enNorm, PIC_UHD4K, &stSize);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("SAMPLE_COMM_SYS_GetPicSize failed!\n");
		goto END_8_1080P_1;
	}

    SAMPLE_COMM_VDEC_ModCommPoolConf(&stModVbConf, PT_H264, &stSize, u32VdCnt, HI_FALSE);	
    s32Ret = SAMPLE_COMM_VDEC_InitModCommVb(&stModVbConf);
	
    if(s32Ret != HI_SUCCESS)
    {	    	
        SAMPLE_PRT("init mod common vb fail for %#x!\n", s32Ret);
        goto END_8_1080P_0;
    }

    /************************************************
    step3:  start VDEC
    *************************************************/
    SAMPLE_COMM_VDEC_ChnAttr(u32VdCnt, &stVdecChnAttr[0], PT_H264, &stSize);
    s32Ret = SAMPLE_COMM_VDEC_Start(u32VdCnt, &stVdecChnAttr[0]);
    if(s32Ret != HI_SUCCESS)
    {	
        SAMPLE_PRT("start VDEC fail for %#x!\n", s32Ret);
        goto END_8_1080P_0;
    }



	/******************************************
	 step 4: start vpss and vi bind vpss
	******************************************/
	s32Ret = SAMPLE_COMM_SYS_GetPicSize(enNorm, PIC_UHD4K, &stSize);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("SAMPLE_COMM_SYS_GetPicSize failed!\n");
		goto END_8_1080P_1;
	}

	memset(&stGrpAttr,0,sizeof(VPSS_GRP_ATTR_S));
	stGrpAttr.u32MaxW = stSize.u32Width;
	stGrpAttr.u32MaxH = stSize.u32Height;
	stGrpAttr.bNrEn = HI_FALSE;//HI_TRUE;
    stGrpAttr.enDieMode = VPSS_DIE_MODE_NODIE;
	stGrpAttr.enPixFmt = SAMPLE_PIXEL_FORMAT;
	s32Ret = SAMPLE_COMM_VPSS_Start(s32VpssGrpCnt, &stSize, VPSS_MAX_CHN_NUM, &stGrpAttr);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Start Vpss failed!\n");
		goto END_8_1080P_1;
	}




	/******************************************
	 step 5: start vo HD0 (bt1120+VGA), multi-screen, you can switch mode
	******************************************/
	printf("start vo HD0.\n");
	VoDev = SAMPLE_VO_DEV_DHD1;
	VoLayer = SAMPLE_VO_LAYER_VHD1;
	u32WndNum = 9;

	if(BOARD == SEND)
	{
		enVoMode =  VO_MODE_4MUX;//VO_MODE_1MUX;//VO_MODE_4MUX;
		stVoPubAttr_hd0.enIntfSync = VO_OUTPUT_1080P60;
		stVoPubAttr_hd0.enIntfType = VO_INTF_BT1120|VO_INTF_VGA;
		stVoPubAttr_hd0.u32BgColor = 0x0;
	}
	
	if(BOARD == READ)
	{
		enVoMode = VO_MODE_1MUX;
		stVoPubAttr_hd0.enIntfSync = VO_OUTPUT_1080P60;
		stVoPubAttr_hd0.enIntfType = /*VO_INTF_BT1120|VO_INTF_VGA|*/VO_INTF_HDMI;
		stVoPubAttr_hd0.u32BgColor = 0x0;		
	}

	
	if(BOARD == READ)
	{
		return 0;
	}
	
	#if 0
	s32Ret = SAMPLE_COMM_VDEC_BindVpss(0, 0);
	if(s32Ret != HI_SUCCESS)
	{		
	SAMPLE_PRT("vdec bind vpss fail for %#x!\n", s32Ret);
	goto END_8_1080P_9;
	}	
	#endif 

	
	/******************************************
	 step 5: start vo HD1 (HDMI), multi-screen, you can switch mode
	******************************************/
	printf("start vo HD1.\n");
	VoDev = SAMPLE_VO_DEV_DHD0;
	VoLayer = SAMPLE_VO_LAYER_VHD0;
	u32WndNum = 16;
	enVoMode = VO_MODE_1MUX;//VO_MODE_9MUX;//VO_MODE_9MUX;//VO_MODE_1MUX;//VO_MODE_4MUX;

	
	stVoPubAttr_hd1.enIntfSync = VO_OUTPUT_1080P60;
	stVoPubAttr_hd1.enIntfType = VO_INTF_HDMI;
	stVoPubAttr_hd1.u32BgColor = 0x0;



	s32Ret = SAMPLE_COMM_VO_StartDev(VoDev, &stVoPubAttr_hd1);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Start SAMPLE_COMM_VO_StartDev failed!\n");
		goto END_8_1080P_5;
	}



	memset(&(stLayerAttr), 0 , sizeof(VO_VIDEO_LAYER_ATTR_S));
	s32Ret = SAMPLE_COMM_VO_GetWH(stVoPubAttr_hd1.enIntfSync, \
		&stLayerAttr.stImageSize.u32Width, \
		&stLayerAttr.stImageSize.u32Height, \
		&stLayerAttr.u32DispFrmRt);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Start SAMPLE_COMM_VO_GetWH failed!\n");
		goto END_8_1080P_6;
	}

	stLayerAttr.enPixFormat = SAMPLE_PIXEL_FORMAT;
    stLayerAttr.stDispRect.s32X       = 0;
    stLayerAttr.stDispRect.s32Y       = 0;
    stLayerAttr.stDispRect.u32Width   = stLayerAttr.stImageSize.u32Width;
    stLayerAttr.stDispRect.u32Height  = stLayerAttr.stImageSize.u32Height;
	s32Ret = SAMPLE_COMM_VO_StartLayer(VoLayer, &stLayerAttr);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Start SAMPLE_COMM_VO_StartLayer failed!\n");
		goto END_8_1080P_6;
	}

	s32Ret = SAMPLE_COMM_VO_StartChn(VoLayer, enVoMode);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Start SAMPLE_COMM_VO_StartChn failed!\n");
		goto END_8_1080P_7;
	}




	
#ifdef HDMI_SUPPORT
	/* if it's displayed on HDMI, we should start HDMI */
	if (stVoPubAttr_hd1.enIntfType & VO_INTF_HDMI)
	{
		if (HI_SUCCESS != SAMPLE_COMM_VO_HdmiStart(stVoPubAttr_hd1.enIntfSync))
		{
			SAMPLE_PRT("Start SAMPLE_COMM_VO_HdmiStart failed!\n");
			goto END_8_1080P_7;
		}
	}
#endif


	#if 1
	u32WndNum = 16;
 	if(BOARD == SEND)
 	{
		for(i=0;i<u32WndNum;i++)
		{
			VoChn = i;
			VpssGrp = i;

			s32Ret = SAMPLE_COMM_VO_BindVpss(VoDev,VoChn,VpssGrp,VpssChn_VoHD1);
			if (HI_SUCCESS != s32Ret)
			{
				goto END_8_1080P_7;
				SAMPLE_PRT("Start VO failed!\n");
			}
		}
	}


	#elif 0
	VoChn = 0;
	VpssGrp = 6;

	
	s32Ret = SAMPLE_COMM_VO_BindVpss(VoDev,VoChn,VpssGrp,VpssChn_VoHD1);
	if (HI_SUCCESS != s32Ret)
	{
		goto END_8_1080P_7;
		SAMPLE_PRT("Start VO failed!\n");
	}	
	#else 
	
	#endif

	#if 1
	if(BOARD == SEND)
	{
		s32Ret = SAMPLE_COMM_VDEC_BindVpss(0, 0);
		if(s32Ret != HI_SUCCESS)
		{	    
			SAMPLE_PRT("vdec bind vpss fail for %#x!\n", s32Ret);
			goto END_8_1080P_9;
		}	
	}

	#elif 1
	
	#endif
	/******************************************
	step 6: start vo SD0 (CVBS)
	******************************************/
	printf("start vo SD0\n");



	#if 1



	VencChn = 0;
	enRcMode = SAMPLE_RC_CBR;
	
	s32Ret = SAMPLE_COMM_VENC_Start(VencChn, PT_H265/*enPayLoad[0]*/,\
								   gs_enNorm, enSize[0], enRcMode,u32Profile);
	if (HI_SUCCESS != s32Ret)
	{
		SAMPLE_PRT("Start Venc failed!\n");
		goto END_8_1080P_9;
	}

	VENC_FRAME_RATE_S stFrameRate;
	stFrameRate.s32DstFrmRate = 25;
	stFrameRate.s32SrcFrmRate = 25;
	//HI_MPI_VENC_SetFrameRate(0,&stFrameRate);
	
	s32Ret = SAMPLE_COMM_VENC_BindVpss(0, 0, 0);

    s32Ret = SAMPLE_COMM_VENC_StartGetStream(1);
    if (HI_SUCCESS != s32Ret)
    {
        SAMPLE_PRT("Start Venc failed!\n");
        goto END_8_1080P_9;
    }

	#endif


	/******************************************
	step 7: HD0 switch mode
	******************************************/
	VoDev = SAMPLE_VO_DEV_DHD0;
	VoLayer = SAMPLE_VO_LAYER_VHD0;
	enVoMode = VO_MODE_9MUX;




	return 0;


	/******************************************
	 step 8: exit process
	******************************************/
END_8_1080P_9:
	VoDev = SAMPLE_VO_DEV_DSD0;
	VoLayer = SAMPLE_VO_LAYER_VSD0;
	u32WndNum = 8;
	enVoMode = VO_MODE_9MUX;
	SAMPLE_COMM_VO_StopChn(VoLayer, enVoMode);
	for(i=0;i<u32WndNum;i++)
	{
		VoChn = i;
		VpssGrp = i;
		SAMPLE_COMM_VO_UnBindVpss(VoLayer,VoChn,VpssGrp,VpssChn_VoSD0);
	}
	SAMPLE_COMM_VO_StopLayer(VoLayer);
END_8_1080P_8:

	SAMPLE_COMM_VO_StopDev(VoDev);

END_8_1080P_7:
	#ifdef HDMI_SUPPORT
	if (stVoPubAttr_hd1.enIntfType & VO_INTF_HDMI)
	{
		SAMPLE_COMM_VO_HdmiStop();
	}
	#endif
	VoDev = SAMPLE_VO_DEV_DHD1;
	VoLayer = SAMPLE_VO_LAYER_VHD1;
	u32WndNum = 8;
	enVoMode = VO_MODE_9MUX;
	SAMPLE_COMM_VO_StopChn(VoLayer, enVoMode);
	for(i=0;i<u32WndNum;i++)
	{
		VoChn = i;
		VpssGrp = i;
		SAMPLE_COMM_VO_UnBindVpss(VoLayer,VoChn,VpssGrp,VpssChn_VoHD1);
	}
	SAMPLE_COMM_VO_StopLayer(VoLayer);

END_8_1080P_6:
	SAMPLE_COMM_VO_StopDev(VoDev);

END_8_1080P_5:

	#ifdef HDMI_SUPPORT
	if (stVoPubAttr_hd0.enIntfType & VO_INTF_HDMI)
	{
		SAMPLE_COMM_VO_HdmiStop();
	}
	#endif

    VoDev = SAMPLE_VO_DEV_DHD0;
	VoLayer = SAMPLE_VO_LAYER_VHD0;
	u32WndNum = 8;
	enVoMode = VO_MODE_9MUX;
	SAMPLE_COMM_VO_StopChn(VoLayer, enVoMode);
	for(i=0;i<u32WndNum;i++)
	{
		VoChn = i;
		VpssGrp = i;
		SAMPLE_COMM_VO_UnBindVpss(VoLayer,VoChn,VpssGrp,VpssChn_VoHD0);
	}
	SAMPLE_COMM_VO_StopLayer(VoLayer);
END_8_1080P_4:
	SAMPLE_COMM_VO_StopDev(VoDev);
END_8_1080P_3:	//vi unbind vpss
	SAMPLE_COMM_VI_UnBindVpss(enViMode);
END_8_1080P_2:	//vpss stop
	SAMPLE_COMM_VPSS_Stop(s32VpssGrpCnt, VPSS_MAX_CHN_NUM);
END_8_1080P_1:	//vi stop
	SAMPLE_COMM_VI_Stop(enViMode);
END_8_1080P_0:	//system exit
	SAMPLE_COMM_SYS_Exit();

	return s32Ret;
}




static int sec_check( void)
{
	printf("\r\n-------------- app sec_check start --------------\r\n");

	if( sec_check_hardware() == 0) {
		printf("sec hardward check success!\r\n");
	} 
	else {
		printf("sec hardward check fail\r\n");
		return SEC_AUTH_FALUE;
	}

	if( sec_auth() == 0) {
		printf("sec auth success!\r\n");
	} 
	else {
		printf("sec auth fail\r\n");
		return SEC_AUTH_FALUE;
	}
	
	if( sec_auth_id( 0x3531D) == 0) {
		printf("sec auth id success!\r\n");
	} 
	else {
		printf("sec auth id fail\r\n");
		return SEC_AUTH_FALUE;
	}
	printf("-------------- app sec_demo end --------------\r\n\r\n");

	return SEC_AUTH_SUCESS;
}


/******************************************************************************
* function    : main()
* Description : video preview sample
******************************************************************************/
int main(int argc, char *argv[])
{
    HI_S32 s32Ret = HI_FAILURE;

	unsigned long long int i = 0;

	ZY_MUXER_ATTR muxerAttr;

	char fileName[512];

	char * pMalloc = NULL;

	vdecInfo vdecInfo;
	unsigned int kkk = 0;

	pthread_t       pid;

	int vdecChn = 0;

	ZY_DEMUXBIND_ATTR Attr;

	char *rtspH264String = "rtsp://admin:Hk123456@192.168.1.199:554/h264/ch1/main/av_stream";

	char *rtspH265String = "rtsp://admin:Hk123456@192.168.1.199:554/h265/ch1/main/av_stream";

	char *rtmpH264String = "rtmp://192.168.1.198:1935/live/stream";

	char * url[] = 
	{
		"rtmp://192.168.1.169:1935/live/livestream",
		//"rtmp://192.168.1.198:1935/hls/stream",
		//"rtmp://192.168.1.198:1935/live/chid",
		"rtmp://pubsec.mudu.tv/watch/3n7t3b?auth_key=2082733261-0-0-7f2b2eec3a190a247694073419f00bf1",
		"rtmp://192.168.1.198:1935/live/stream2",
		"rtmp://192.168.1.198:1935/live/stream3",
		"rtmp://192.168.1.198:1935/live/stream4",
		"rtmp://192.168.1.198:1935/live/stream5",
		"rtmp://192.168.1.198:1935/live/stream6",
		"rtmp://192.168.1.198:1935/live/stream7",
		"rtmp://192.168.1.198:1935/live/stream8",

	};



    signal(SIGINT, SAMPLE_VIO_HandleSig);
    signal(SIGTERM, SAMPLE_VIO_HandleSig);
	
	if(sec_check() < 0)
	{
		printf("sec check error,please contact www.zhiyang-tech.com\r\n");
		exit(0);
	}



	#if 1
	
	s32Ret = ZY_Video_Sample();
	s32Ret = ZY_AUDIO_TLV320AIC31AiAo();
	
	
	ZY_MPI_RtspServer_Init();
	ZY_MPI_RtmpPush_Init();
	ZY_MPI_Muxer_Init();
	ZY_MPI_Demux_Init();



	#endif 

	



	ZY_OSD_ATTR_S attr;
	ZY_OSD_DST_ATTR dstAttr;
	ZY_OSD_SHOW_ATTR_S showAttr;

	s32Ret = ZY_MPI_OSD_CreateChn(0);
	DEBUG("s32Ret=0x%x\r\n",s32Ret);


	
	memset(&attr,0,sizeof(attr));
	attr.enPixelFmt = ZY_PIXEL_FORMAT_RGB_8888;
	attr.stSize.u32Width =  1920;
	attr.stSize.u32Height=  200;
	s32Ret = ZY_MPI_OSD_SetChnAttr(0,attr);
	DEBUG("s32Ret=0x%x\r\n",s32Ret);

	
	dstAttr.dstChn = 0;
	dstAttr.dstType = ZY_OSD_BINDVPSS;
	dstAttr.Osdlayer = 0;
	showAttr.stPoint.s32X = 0;
	showAttr.stPoint.s32Y = 0;
	s32Ret = ZY_MPI_OSD_BindDst(0,dstAttr,ZY_TRUE,showAttr);
	DEBUG("s32Ret=0x%x\r\n",s32Ret);



	//osd show
	s32Ret = ZY_MPI_OSD_SetShow(0,"Hi 深圳市知扬科技有限公司 ",ZY_OSD_TEXT,0x000000ff,124,&kkk,&kkk,ZY_TRUE);//utf-8
	DEBUG("s32Ret=0x%x\r\n",s32Ret);


	while(1)
	{

		#if 1
		for(kkk = 0; kkk < 1;kkk++)
		{
			//printf("rtsp client chn=%d  \r\n",i);
			ZY_MPI_Demux_CreateChn(kkk,(const char *)rtspH264String);
			
			//ZY_MPI_Demux_CreateChn(kkk,(const char *)rtspH265String);
			//ZY_MPI_Demux_CreateChn(kkk,(const char *)rtmpH264String);
			//ZY_MPI_Demux_CreateChn(kkk,(const char *)"/tmp/ok-264-1080P.mkv");
			
			//ZY_MPI_Demux_CreateChn(kkk,(const char *)"/tmp/h265-test0.mp4");
			//ZY_MPI_Demux_CreateChn(kkk,(const char *)"/tmp/4k.mp4");
			//ZY_MPI_Demux_CreateChn(kkk,(const char *)"222.aac");
			//ZY_MPI_Demux_CreateChn(kkk,(const char *)"yingxiong.mp4");
			Attr.AdecBlock = 0;//1;
			Attr.VdecBlock = 0;//-1;
			Attr.chn	   = kkk;
			Attr.ctrl	   = DEMUX_CTRL_START;
			Attr.timeMode = ZY_TIMESTAMP_MODE_FULL;//ZY_TIMESTAMP_MODE_SYNC;//ZY_TIMESTAMP_MODE_FULL;//ZY_TIMESTAMP_MODE_SYNC;
			ZY_MPI_Demux_BindVdecAdec(kkk,Attr);
			
		}

		
		#endif 
		#if 1
		printf("start record\r\n");
	    for(kkk = 0; kkk < 1;kkk++)
	    {

			memset(&muxerAttr,0,sizeof(muxerAttr));
			muxerAttr.width = 1920;
			muxerAttr.height = 1080;
			muxerAttr.fps = ZY_PIC_FPS_60;
			#if 1

			muxerAttr.bitWidth = ZY_AUDIO_BIT_WIDTH_16;
			muxerAttr.chnMode = ZY_AUDIO_SOUND_MODE_STEREO ;
			muxerAttr.sample_rate = ZY_AUDIO_SAMPLERATE_48000;
			muxerAttr.bitRate = ZY_AUDIO_BIT_RATE_128000; 
			#endif 

			
			memset(fileName,0,sizeof(fileName));
			//sprintf(fileName,"./h265-chn%d.mp4",kkk); //mp4
			sprintf(fileName,"./h265-chn%d.ts",kkk); //ts

			strcpy(muxerAttr.fileName,fileName);
			muxerAttr.type = ZY_VIDEOAUDIO;
			muxerAttr.vencType = ZY_H265;
			printf("muxerAttr.fileName=%s  \r\n",muxerAttr.fileName);
			//kkk = kkk - 10;
			ZY_MPI_Muxer_CreateChn(kkk,&muxerAttr);
	    }

		sleep(20); //record 20S
		for(kkk = 0; kkk < 1;kkk++)
		{
			ZY_MPI_Muxer_DetroyChn(kkk);
		}
		#endif 


		sleep(60 * 1000);

		for(kkk = 0; kkk < 1;kkk++)
		{
			//printf("ZY_MPI_Demux_DestroyChn chn=%d  \r\n",kkk);
			ZY_MPI_Demux_DestroyChn(kkk);
		}
		

		
		printf("run ***************************%lld!\n",i);
		exit(0);


	}
	



}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */

