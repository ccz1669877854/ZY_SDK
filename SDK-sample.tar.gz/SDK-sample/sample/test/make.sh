make clean && make && cp ZY_Project  /source/rootfs/HI3531D/
